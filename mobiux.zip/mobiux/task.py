def read_data_from_file(file_path):
    with open(file_path, "r") as file:
        lines = file.readlines()
    return [line.strip() for line in lines]

file_path = "data.txt"
data = read_data_from_file(file_path)

sales_data = []
for entry in data:
    date, item, price, quantity, revenue = entry.split(",")
    sales_data.append({
        "date": date,
        "item": item,
        "price": int(price),
        "quantity": int(quantity),
        "revenue": int(revenue)
    })

total_sales = 0
month_wise_sales = {}
month_wise_items = {}

for sale in sales_data:
    total_sales += sale["revenue"]

    month = sale["date"][:7]

    if month not in month_wise_sales:
        month_wise_sales[month] = 0
        month_wise_items[month] = {}
    month_wise_sales[month] += sale["revenue"]

    if sale["item"] not in month_wise_items[month]:
        month_wise_items[month][sale["item"]] = {"quantity": 0, "revenue": 0}
    month_wise_items[month][sale["item"]]["quantity"] += sale["quantity"]
    month_wise_items[month][sale["item"]]["revenue"] += sale["revenue"]

results = {}

for month, items in month_wise_items.items():
    most_popular = max(items.items(), key=lambda x: x[1]["quantity"])
    most_revenue = max(items.items(), key=lambda x: x[1]["revenue"])
    popular_item = most_popular[0]
    quantities = [sale["quantity"] for sale in sales_data if sale["date"].startswith(month) and sale["item"] == popular_item]

    results[month] = {
        "most_popular_item": popular_item,
        "most_popular_stats": {"min": min(quantities), "max": max(quantities), "average": sum(quantities) / len(quantities)},
        "most_revenue_item": most_revenue[0],
        "most_revenue_amount": most_revenue[1]["revenue"]
    }

print(f"Total Sales: {total_sales}")
print("\nMonth-wise Sales:")
for month, total in month_wise_sales.items():
    print(f"{month}: {total}")

print("\nMonthly Metrics:")
for month, metrics in results.items():
    print(f"{month}:")
    print(f"  Most Popular Item: {metrics['most_popular_item']} (Min: {metrics['most_popular_stats']['min']}, Max: {metrics['most_popular_stats']['max']}, Avg: {metrics['most_popular_stats']['average']:.2f})")
    print(f"  Item Generating Most Revenue: {metrics['most_revenue_item']} (Revenue: {metrics['most_revenue_amount']})")
